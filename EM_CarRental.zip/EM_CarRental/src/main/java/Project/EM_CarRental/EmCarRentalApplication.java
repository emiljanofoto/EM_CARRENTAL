package Project.EM_CarRental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmCarRentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmCarRentalApplication.class, args);
	}

}
