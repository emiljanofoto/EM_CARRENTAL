package Project.EM_CarRental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmCarRentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
